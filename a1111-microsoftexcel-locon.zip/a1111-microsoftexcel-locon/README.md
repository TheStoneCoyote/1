# [Deprecated] a1111-sd-webui-locon [Deprecated]

### **YOU SHOULD USE a1111-sd-webui-lycoris**
https://github.com/KohakuBlueleaf/a1111-sd-webui-lycoris

**This extension is basically deprecated and will not have any official update at all. Please consider to use [a1111-sd-webui-lycoris](https://github.com/KohakuBlueleaf/a1111-sd-webui-lycoris) instead**
(but if there are new PRs, I will accept them)
**If you meet any problem or error when using this extension, please consider remove it and install lycoris extension ↑**


---

---

An extension for loading lycoris model in sd-webui. (include locon and loha)

# THIS EXTENSION IS NOT FOR ADDITIONAL NETWORK

### LyCORIS
https://github.com/KohakuBlueleaf/LyCORIS

### usage
Install and use locon model as lora model. <br>
Make sure your sd-webui has built-in lora

![image](https://user-images.githubusercontent.com/59680068/222327303-9ba4f702-5821-48db-a849-337dce9b11bb.png)
